#include "dummy.h"


void testClass::testClass()
{
	
	
}
