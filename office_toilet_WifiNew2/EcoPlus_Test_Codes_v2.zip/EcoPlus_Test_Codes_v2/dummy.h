
#include "Arduino.h"

class testClass
{
	public:
	byte test11;
	testClass();

};


