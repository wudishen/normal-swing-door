var class_s_w___s_p_i_class =
[
    [ "SW_SPIClass", "class_s_w___s_p_i_class.html#abab6ad0e3672f88cb059c7885d0c4388", null ],
    [ "begin", "class_s_w___s_p_i_class.html#a70ac0130662f2dd4692a922832932ce2", null ],
    [ "endTransaction", "class_s_w___s_p_i_class.html#ad521bec524a75beac5d81eea414a8b6b", null ],
    [ "init", "class_s_w___s_p_i_class.html#aa35a68a7e184e42445f391876e58dd68", null ],
    [ "transfer", "class_s_w___s_p_i_class.html#af260fdc0af3f1312b106483161e559c3", null ],
    [ "transfer16", "class_s_w___s_p_i_class.html#a1b7600aa1d9571c103718c5d3e376675", null ]
];