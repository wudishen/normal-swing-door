var namespace_t_m_c2209__n =
[
    [ "COOLCONF_t", "struct_t_m_c2209__n_1_1_c_o_o_l_c_o_n_f__t.html", "struct_t_m_c2209__n_1_1_c_o_o_l_c_o_n_f__t" ],
    [ "IOIN_t", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html", "struct_t_m_c2209__n_1_1_i_o_i_n__t" ],
    [ "SG_RESULT_t", "struct_t_m_c2209__n_1_1_s_g___r_e_s_u_l_t__t.html", "struct_t_m_c2209__n_1_1_s_g___r_e_s_u_l_t__t" ],
    [ "SGTHRS_t", "struct_t_m_c2209__n_1_1_s_g_t_h_r_s__t.html", "struct_t_m_c2209__n_1_1_s_g_t_h_r_s__t" ]
];