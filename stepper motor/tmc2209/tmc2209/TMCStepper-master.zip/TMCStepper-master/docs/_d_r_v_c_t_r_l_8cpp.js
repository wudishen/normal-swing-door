var _d_r_v_c_t_r_l_8cpp =
[
    [ "GET_REG0", "_d_r_v_c_t_r_l_8cpp.html#a2543a2e98c05e6772d620d3c538ef0c4", null ],
    [ "GET_REG1", "_d_r_v_c_t_r_l_8cpp.html#a2d160d3af75cffb12b479504897a995d", null ],
    [ "SET_REG0", "_d_r_v_c_t_r_l_8cpp.html#a0106901688e6b216cfea491ef26cf85f", null ],
    [ "SET_REG1", "_d_r_v_c_t_r_l_8cpp.html#a4ff3043b0f9b12262b29bb6d2a18bf43", null ]
];