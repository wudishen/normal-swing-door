var searchData=
[
  ['x_5fcompare_896',['X_COMPARE',['../class_t_m_c5130_stepper.html#a694840324312e15515f3215c83565645',1,'TMC5130Stepper::X_COMPARE()'],['../class_t_m_c5130_stepper.html#a9f07f02f86043e2f6838d981c8640a85',1,'TMC5130Stepper::X_COMPARE(uint32_t input)']]],
  ['x_5fenc_897',['X_ENC',['../class_t_m_c5130_stepper.html#a432764a59619856079ecfb56ee426f2d',1,'TMC5130Stepper::X_ENC()'],['../class_t_m_c5130_stepper.html#a96df3216ae2849d3ad7252ea9f27edbb',1,'TMC5130Stepper::X_ENC(int32_t input)']]],
  ['xactual_898',['XACTUAL',['../class_t_m_c5130_stepper.html#a7ddd27bea8034e6aec78ab2cf83cedd4',1,'TMC5130Stepper::XACTUAL()'],['../class_t_m_c5130_stepper.html#a94b69d8b20ac649d53eba036afdbbe41',1,'TMC5130Stepper::XACTUAL(int32_t input)']]],
  ['xdirect_899',['XDIRECT',['../class_t_m_c2130_stepper.html#af486cd4712be021c735fc3bcb8eee9f5',1,'TMC2130Stepper::XDIRECT()'],['../class_t_m_c2130_stepper.html#a879bf37d4369f73fe5e238c8181d1dd1',1,'TMC2130Stepper::XDIRECT(uint32_t input)']]],
  ['xlatch_900',['XLATCH',['../class_t_m_c5130_stepper.html#aa027fe70ea5dc43b7bb0ac4452b4cbc3',1,'TMC5130Stepper']]],
  ['xtarget_901',['XTARGET',['../class_t_m_c5130_stepper.html#ae33c13bf7dc95cd8a8a4d8e1c444f9e5',1,'TMC5130Stepper::XTARGET()'],['../class_t_m_c5130_stepper.html#ac6db9621fa769994b3b6481ba3043b4b',1,'TMC5130Stepper::XTARGET(int32_t input)']]]
];
