var searchData=
[
  ['readmiso_1143',['readMISO',['../_t_m_c__platforms_8h.html#a1b0729059441b53f83a633fbf0ab315f',1,'TMC_platforms.h']]]
];
