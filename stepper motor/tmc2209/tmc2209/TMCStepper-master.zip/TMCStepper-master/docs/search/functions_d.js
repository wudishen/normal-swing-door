var searchData=
[
  ['offset_5fread_745',['OFFSET_READ',['../class_t_m_c2160_stepper.html#a6e35363428a742e1e14cf225e683fa4c',1,'TMC2160Stepper']]],
  ['ola_746',['ola',['../class_t_m_c2130_stepper.html#a4498e65bf73b9d5e38c2a7b2ec04240a',1,'TMC2130Stepper::ola()'],['../class_t_m_c2208_stepper.html#ada2e940e7c0a98ad75fe77e329d402b5',1,'TMC2208Stepper::ola()'],['../class_t_m_c2660_stepper.html#a790a78329e575ef39a0219a59d8d5b0b',1,'TMC2660Stepper::ola()']]],
  ['olb_747',['olb',['../class_t_m_c2130_stepper.html#a078e86b80201315ccd66f25d03551e5d',1,'TMC2130Stepper::olb()'],['../class_t_m_c2208_stepper.html#ad7a64b03dde9d5699f731bbb9fe88dba',1,'TMC2208Stepper::olb()'],['../class_t_m_c2660_stepper.html#a70ecc683c065c3067ca48aafdec740e7',1,'TMC2660Stepper::olb()']]],
  ['ot_748',['ot',['../class_t_m_c2130_stepper.html#acd37d8c3da54e0596a3cb18299acd347',1,'TMC2130Stepper::ot()'],['../class_t_m_c2208_stepper.html#a8aa9eb6675d35d3c697badf6009f62e4',1,'TMC2208Stepper::ot()'],['../class_t_m_c2660_stepper.html#a16330eb11b15930e16b6dd71fc798d8f',1,'TMC2660Stepper::ot()']]],
  ['otp_5fprog_749',['OTP_PROG',['../class_t_m_c2208_stepper.html#a755b2adec0990d6bfcf2f5f1daf9d692',1,'TMC2208Stepper']]],
  ['otp_5fread_750',['OTP_READ',['../class_t_m_c2208_stepper.html#a0727482b76d6cd679021f4d1677e5b3a',1,'TMC2208Stepper']]],
  ['otpw_751',['otpw',['../class_t_m_c2130_stepper.html#a013e8ad00535470bc46bd9913baf9727',1,'TMC2130Stepper::otpw()'],['../class_t_m_c2208_stepper.html#a4e511e4440ca75cf2a0bddcda52ad12c',1,'TMC2208Stepper::otpw()'],['../class_t_m_c2660_stepper.html#a76c77714558be0359cb7fb6099b00ce3',1,'TMC2660Stepper::otpw()']]],
  ['otselect_752',['otselect',['../class_t_m_c2160_stepper.html#a4e954ffd8274200489571980f91da028',1,'TMC2160Stepper::otselect(uint8_t)'],['../class_t_m_c2160_stepper.html#ae804290cc33d87371267f1181f83934f',1,'TMC2160Stepper::otselect()']]],
  ['ottrim_753',['ottrim',['../class_t_m_c2208_stepper.html#ae51fb40f4fba4aecb8f0763adddb8296',1,'TMC2208Stepper::ottrim(uint8_t B)'],['../class_t_m_c2208_stepper.html#a1d354657666fa70cd13004cb70bc9fcf',1,'TMC2208Stepper::ottrim()']]]
];
